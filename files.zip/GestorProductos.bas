Option Explicit

Sub ImportarJSON()
    Dim filePath As Variant
    Dim jsonText As String
    Dim jsonObj As Object
    Dim productos As Object
    Dim i As Long
    Dim ws As Worksheet
    
    CreateJsonParser
    
    filePath = Application.GetOpenFilename("Archivos JSON (*.json),*.json", , "Selecciona el archivo JSON")
    If filePath = False Then Exit Sub
    
    Open filePath For Input As #1
    jsonText = Input$(LOF(1), 1)
    Close #1
    
    Set jsonObj = ParseJson(jsonText)
    
    Set ws = ThisWorkbook.Sheets(1)
    ws.Cells.Clear
    ws.Cells.ClearContents
    
    With ws
        .Range("A1") = "id"
        .Range("B1") = "nombreKey"
        .Range("C1") = "nombre"
        .Range("D1") = "descripcion"
        .Range("E1") = "precioUnidad"
        .Range("F1") = "precioCaja"
        .Range("G1") = "categoria"
        .Range("H1") = "etiqueta"
        .Range("I1") = "imagen"
        
        .Range("A1:I1").Font.Bold = True
        .Range("A1:I1").Interior.Color = RGB(220, 220, 220)
        .Columns("A:I").AutoFit
    End With
    
    For i = 0 To UBound(jsonObj)
        ws.Range("A" & i + 2) = jsonObj(i)("id")
        ws.Range("B" & i + 2) = jsonObj(i)("nombreKey")
        ws.Range("C" & i + 2) = jsonObj(i)("nombre")
        ws.Range("D" & i + 2) = jsonObj(i)("descripcion")
        ws.Range("E" & i + 2) = jsonObj(i)("precioUnidad")
        ws.Range("F" & i + 2) = jsonObj(i)("precioCaja")
        ws.Range("G" & i + 2) = jsonObj(i)("categoria")
        ws.Range("H" & i + 2) = jsonObj(i)("etiqueta")
        ws.Range("I" & i + 2) = jsonObj(i)("imagen")
    Next i
    
    AgregarValidaciones
    
    MsgBox "¡Importados " & (i) & " productos!", vbInformation
End Sub

Sub ExportarJSON()
    Dim filePath As Variant
    Dim lastRow As Long
    Dim i As Long
    Dim jsonText As String
    Dim ws As Worksheet
    
    filePath = Application.GetSaveAsFilename( _
        InitialFileName:="productos_actualizado.json", _
        fileFilter:="Archivos JSON (*.json),*.json")
    
    If filePath = False Then Exit Sub
    
    Set ws = ThisWorkbook.Sheets(1)
    lastRow = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row
    
    If lastRow < 2 Then
        MsgBox "No hay datos", vbExclamation
        Exit Sub
    End If
    
    jsonText = "[" & vbNewLine
    
    For i = 2 To lastRow
        If ws.Range("A" & i) <> "" Then
            jsonText = jsonText & "    {" & vbNewLine
            jsonText = jsonText & "        ""id"": " & ws.Range("A" & i) & "," & vbNewLine
            jsonText = jsonText & "        ""nombreKey"": """ & EscapeJson(ws.Range("B" & i)) & """," & vbNewLine
            jsonText = jsonText & "        ""nombre"": """ & EscapeJson(ws.Range("C" & i)) & """," & vbNewLine
            jsonText = jsonText & "        ""descripcion"": """ & EscapeJson(ws.Range("D" & i)) & """," & vbNewLine
            jsonText = jsonText & "        ""precioUnidad"": " & ws.Range("E" & i) & "," & vbNewLine
            jsonText = jsonText & "        ""precioCaja"": " & ws.Range("F" & i) & "," & vbNewLine
            jsonText = jsonText & "        ""categoria"": """ & EscapeJson(ws.Range("G" & i)) & """," & vbNewLine
            jsonText = jsonText & "        ""etiqueta"": """ & EscapeJson(ws.Range("H" & i)) & """," & vbNewLine
            jsonText = jsonText & "        ""imagen"": """ & EscapeJson(ws.Range("I" & i)) & """"
            jsonText = jsonText & "    }"
            
            If i < lastRow Then
                If ws.Range("A" & i + 1) <> "" Then jsonText = jsonText & ","
            End If
            jsonText = jsonText & vbNewLine
        End If
    Next i
    
    jsonText = jsonText & "]"
    
    Open filePath For Output As #1
    Print #1, jsonText
    Close #1
    
    MsgBox "¡Exportados " & (lastRow - 1) & " productos!", vbInformation
End Sub

Function EscapeJson(ByVal texto As Variant) As String
    If IsNull(texto) Or texto = "" Then
        EscapeJson = ""
        Exit Function
    End If
    
    Dim temp As String
    temp = Replace(texto, "\", "\\")
    temp = Replace(temp, """", "\""")
    temp = Replace(temp, vbCrLf, "\n")
    temp = Replace(temp, vbLf, "\n")
    EscapeJson = temp
End Function

Sub AgregarValidaciones()
    Dim ws As Worksheet
    Dim lastRow As Long
    Dim categorias As Variant
    Dim etiquetas As Variant
    
    Set ws = ThisWorkbook.Sheets(1)
    lastRow = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row
    
    categorias = Array("Mermeladas", "Galletas", "Chocolates", "Salsas", "Despensa", "Bebidas")
    etiquetas = Array("ARTESANAL", "TRADICION", "EXOTICO", "PREMIUM", "POPULAR", "CLASICO", _
                     "ECONOMICO", "ESPECIAL", "INFANTIL", "PICANTE", "TIPICO", "REFRESCANTE", "SOPAS")
    
    If lastRow >= 2 Then
        With ws.Range("G2:G" & lastRow).Validation
            .Delete
            .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
                 Formula1:=Join(categorias, ",")
            .IgnoreBlank = True
            .InCellDropdown = True
        End With
        
        With ws.Range("H2:H" & lastRow).Validation
            .Delete
            .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
                 Formula1:=Join(etiquetas, ",")
            .IgnoreBlank = True
            .InCellDropdown = True
        End With
    End If
End Sub

Sub NuevoProducto()
    Dim ws As Worksheet
    Dim lastRow As Long
    Dim newRow As Long
    Dim maxID As Long
    
    Set ws = ThisWorkbook.Sheets(1)
    lastRow = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row
    newRow = lastRow + 1
    
    On Error Resume Next
    maxID = Application.WorksheetFunction.Max(ws.Range("A2:A" & lastRow))
    On Error GoTo 0
    
    If maxID = 0 Then maxID = 1
    
    ws.Range("A" & newRow) = maxID + 1
    ws.Range("B" & newRow) = "prod_nuevo"
    ws.Range("C" & newRow) = "Nuevo Producto"
    ws.Range("I" & newRow) = "./assets/img/nuevo_producto.png"
    
    AgregarValidaciones
    
    ws.Range("A" & newRow).Select
    MsgBox "Nuevo producto agregado en fila " & newRow
End Sub

Sub ActualizarImagenes()
    Dim ws As Worksheet
    Dim lastRow As Long
    Dim i As Long
    Dim count As Long
    
    Set ws = ThisWorkbook.Sheets(1)
    lastRow = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row
    count = 0
    
    For i = 2 To lastRow
        If ws.Range("I" & i) = "" Then
            Dim nombreKey As String
            nombreKey = ws.Range("B" & i)
            If nombreKey <> "" Then
                nombreKey = Replace(nombreKey, "prod_", "")
                ws.Range("I" & i) = "./assets/img/" & nombreKey & ".png"
                count = count + 1
            End If
        End If
    Next i
    
    MsgBox "Imagenes actualizadas para " & count & " productos"
End Sub

Function ParseJson(jsonText As String) As Variant
    Dim items() As Variant
    Dim lines() As String
    Dim i As Long, j As Long
    Dim item As Object
    Dim inItem As Boolean
    Dim itemText As String
    
    lines = Split(jsonText, vbLf)
    ReDim items(0)
    j = 0
    
    For i = 0 To UBound(lines)
        If InStr(lines(i), "{") > 0 Then
            inItem = True
            itemText = ""
        End If
        
        If inItem Then
            itemText = itemText & lines(i) & vbLf
        End If
        
        If InStr(lines(i), "}") > 0 And inItem Then
            inItem = False
            Set item = ParseItem(itemText)
            If Not item Is Nothing Then
                ReDim Preserve items(j)
                Set items(j) = item
                j = j + 1
            End If
        End If
    Next i
    
    ParseJson = items
End Function

Function ParseItem(itemText As String) As Object
    Dim dict As Object
    Dim lines() As String
    Dim i As Long
    Dim parts() As String
    Dim key As String
    Dim value As String
    
    Set dict = CreateObject("Scripting.Dictionary")
    lines = Split(itemText, ",")
    
    For i = 0 To UBound(lines)
        If InStr(lines(i), ":") > 0 Then
            parts = Split(lines(i), ":")
            If UBound(parts) >= 1 Then
                key = Trim(Replace(parts(0), """", ""))
                key = Trim(Replace(key, "{", ""))
                value = Trim(parts(1))
                value = Trim(Replace(value, """", ""))
                value = Trim(Replace(value, "}", ""))
                dict(key) = value
            End If
        End If
    Next i
    
    Set ParseItem = dict
End Function

Sub CreateJsonParser()
    On Error Resume Next
    ThisWorkbook.VBProject.References.AddFromFile "C:\Windows\System32\scrrun.dll"
    On Error GoTo 0
End Sub

Sub CrearBotones()
    Dim ws As Worksheet
    Dim btn As Object
    
    Set ws = ThisWorkbook.Sheets(1)
    
    On Error Resume Next
    ws.Buttons.Delete
    On Error GoTo 0
    
    Set btn = ws.Buttons.Add(ws.Range("K1").Left, ws.Range("K1").Top, 120, 30)
    btn.OnAction = "ImportarJSON"
    btn.Caption = "Importar JSON"
    
    Set btn = ws.Buttons.Add(ws.Range("L1").Left, ws.Range("L1").Top, 120, 30)
    btn.OnAction = "ExportarJSON"
    btn.Caption = "Exportar JSON"
    
    Set btn = ws.Buttons.Add(ws.Range("M1").Left, ws.Range("M1").Top, 120, 30)
    btn.OnAction = "NuevoProducto"
    btn.Caption = "Nuevo Producto"
    
    Set btn = ws.Buttons.Add(ws.Range("N1").Left, ws.Range("N1").Top, 140, 30)
    btn.OnAction = "ActualizarImagenes"
    btn.Caption = "Actualizar Imagenes"
End Sub
