Private Sub Workbook_Open()
    Call CrearBotones
    
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets(1)
    
    ws.Range("A4") = "INSTRUCCIONES RAPIDAS:"
    ws.Range("A5") = "Usa los botones de arriba (columnas K-N)"
    ws.Range("A6") = "Categorias y etiquetas tienen lista desplegable"
    ws.Range("A7") = "Las imagenes deben estar en ./assets/img/"
    ws.Range("A4:A7").Font.Bold = True
    ws.Range("A4:A7").Font.Color = RGB(0, 0, 255)
    
    AgregarValidaciones
End Sub
